================
Duktape releases
================

Release information can be found at https://duktape.org/download.html.
Raw release metadata is maintained in https://github.com/svaarala/duktape/tree/master/releases.
