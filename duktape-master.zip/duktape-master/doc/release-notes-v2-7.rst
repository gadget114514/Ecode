=========================
Duktape 2.7 release notes
=========================

Release overview
================

Main changes in this release (see RELEASES.rst for full details):

* Various fixes and portability improvements.

Upgrading from Duktape 2.6
==========================

No action (other than recompiling) should be needed for most users to upgrade
from Duktape v2.6.x.
